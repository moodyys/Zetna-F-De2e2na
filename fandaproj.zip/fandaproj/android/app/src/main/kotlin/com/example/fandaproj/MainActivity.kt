package com.example.fandaproj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
