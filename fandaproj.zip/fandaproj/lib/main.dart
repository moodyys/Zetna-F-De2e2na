import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
void main() {
  runApp(const MyApp());}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
       primarySwatch: Colors.blue
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Zetna Fi de2e2na',
          style: GoogleFonts.dancingScript(
            fontSize: 36,
            color: Color(0xffFF1A75),
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true, // Centers the title in the AppBar
      ),
      body: HomeScreenBody(),
    );
  }
}
class HomeScreenBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search for recipes...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: 10, // Placeholder count for recipes
            itemBuilder: (context, index) {
              return RecipeCard(); // Placeholder for each recipe card
            },
          ),
        ),
      ],
    );
  }
}
class RecipeCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding:const EdgeInsets.all(16),
        leading: const Icon(Icons.fastfood), // Placeholder icon
        title: const Text("Recipe Title Placeholder"),
        subtitle: const Text("Description of the recipe..."),
        trailing: const Icon(Icons.favorite_border), // Favorite button placeholder
        onTap: () {
          // Navigate to Recipe Details Screen
        },
      ),
    );
  }
}
